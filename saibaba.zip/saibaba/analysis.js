const scoreDisplay = document.getElementById('scoreDisplay');
const scoreChart = document.getElementById('scoreChart');

let score = localStorage.getItem('testScore');
scoreDisplay.textContent = `Your score: ${score}`;

const totalQuestions = 10; // Total number of questions
const highThreshold = Math.round(totalQuestions * 0.7); // High score threshold (70% and above)
const mediumThreshold = Math.round(totalQuestions * 0.4); // Medium score threshold (40% and above)

let highScore = score >= highThreshold ? score : 0;
let mediumScore = score < highThreshold && score >= mediumThreshold ? score : 0;
let lowScore = score < mediumThreshold ? score : 0;

const ctx = scoreChart.getContext('2d');
const chart = new Chart(ctx, {
    type: 'bar',
    data: {
        labels: ['High Knowledge', 'Medium Knowledge', 'Low Knowledge'],
        datasets: [{
            label: 'Scores',
            data: [highScore, mediumScore, lowScore],
            backgroundColor: [
                'rgba(75, 192, 192, 0.2)',
                'rgba(255, 206, 86, 0.2)',
                'rgba(255, 99, 132, 0.2)'
            ],
            borderColor: [
                'rgba(75, 192, 192, 1)',
                'rgba(255, 206, 86, 1)',
                'rgba(255, 99, 132, 1)'
            ],
            borderWidth: 1
        }]
    },
    options: {
        scales: {
            y: {
                beginAtZero: true
            }
        }
    }
});

// Restart game button functionality
document.getElementById('restartGameBtn').addEventListener('click', () => {
    localStorage.removeItem('testScore'); // Clear stored score
    window.location.href = 'index.html'; // Redirect to main game page
});
