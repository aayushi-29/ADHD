// Game Variables
let currentFoodIndex = 0;
let currentLevel = 'easy';
let score = 0;
let levelScores = { easy: 0, medium: 0, hard: 0 };

// Food Items for Each Level
const levels = {
    easy: [
        { name: 'Apple', group: 'fruits', img: 'assets/apple.png' },
        { name: 'Carrot', group: 'vegetables', img: 'assets/carrot.png' },
        { name: 'Banana', group: 'fruits', img: 'assets/banana.png' },
        { name: 'Tomato', group: 'vegetables', img: 'assets/tomato.png' }
    ],
    medium: [
        { name: 'Bread', group: 'grains', img: 'assets/bread.png' },
        { name: 'Chicken', group: 'proteins', img: 'assets/chicken.png' },
        { name: 'Rice', group: 'grains', img: 'assets/rice.png' },
        { name: 'Fish', group: 'proteins', img: 'assets/fish.png' }
    ],
    hard: [
        { name: 'Milk', group: 'dairy', img: 'assets/milk.png' },
        { name: 'Egg', group: 'proteins', img: 'assets/egg.png' },
        { name: 'Cheese', group: 'dairy', img: 'assets/cheese.png' },
        { name: 'Yogurt', group: 'dairy', img: 'assets/yogurt.png' }
    ]
};

// Function to Load Current Food Item
function loadFood() {
    const food = levels[currentLevel][currentFoodIndex];
    const foodElement = document.getElementById('current-food');
    foodElement.src = food.img;
    foodElement.alt = food.name;

    // Voice Assistance for Food Item
    const foodMessage = new SpeechSynthesisUtterance(`Sort the ${food.name} into the correct category.`);
    window.speechSynthesis.speak(foodMessage);
}

// Allow Drop Function
function allowDrop(ev) {
    ev.preventDefault();
}

// Drag Food Function
function drag(ev) {
    ev.dataTransfer.setData("text", ev.target.id);
}

// Drop Food Function
function drop(ev) {
    ev.preventDefault();
    const category = ev.target.getAttribute('data-category');
    const food = levels[currentLevel][currentFoodIndex];

    if (category === food.group) {
        score += 10;
        document.getElementById('feedback').innerText = 'Correct!';
    } else {
        document.getElementById('feedback').innerText = 'Try Again!';
    }

    // Update Score
    document.getElementById('score').innerText = score;

    // Voice Assistance for Feedback
    const feedbackMessage = new SpeechSynthesisUtterance(document.getElementById('feedback').innerText);
    window.speechSynthesis.speak(feedbackMessage);

    // Move to Next Food Item
    currentFoodIndex++;
    if (currentFoodIndex < levels[currentLevel].length) {
        loadFood();
    } else {
        document.getElementById('feedback').innerText = `Level ${currentLevel.charAt(0).toUpperCase() + currentLevel.slice(1)} Completed!`;
        document.getElementById('next-level').classList.remove('hidden');
        document.getElementById('show-visualization').classList.remove('hidden');

        // Store Score for the Current Level
        levelScores[currentLevel] = score;
        localStorage.setItem('levelScores', JSON.stringify(levelScores));
    }
}

// Next Level Button
document.getElementById('next-level').addEventListener('click', function() {
    if (currentLevel === 'easy') {
        currentLevel = 'medium';
    } else if (currentLevel === 'medium') {
        currentLevel = 'hard';
    }

    currentFoodIndex = 0;
    score = 0;
    document.getElementById('score').innerText = score;
    document.getElementById('feedback').innerText = '';
    document.getElementById('current-level').innerText = currentLevel.charAt(0).toUpperCase() + currentLevel.slice(1);
    document.getElementById('next-level').classList.add('hidden');
    loadFood();
});

// Show Score Visualization Button
document.getElementById('show-visualization').addEventListener('click', function() {
    window.location.href = 'visualization.html';
});

// Start the Game with the First Food Item
window.onload = function() {
    loadFood();
};
