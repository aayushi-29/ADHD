const categories = {
    "Professions and Tools": {
        easy: ["Doctor", "Teacher", "Firefighter"],
        medium: ["Doctor", "Teacher", "Firefighter", "Chef", "Pilot"],
        hard: ["Doctor", "Teacher", "Firefighter", "Chef", "Pilot", "Artist", "Engineer", "Farmer"],
        matches: {
            "Doctor": "Stethoscope",
            "Teacher": "Chalkboard",
            "Firefighter": "Fire Truck",
            "Chef": "Chef's Knife",
            "Pilot": "Airplane",
            "Artist": "Paintbrush",
            "Engineer": "Blueprints",
            "Farmer": "Tractor"
        }
    },
    "Shapes and Objects": {
        easy: ["Circle", "Square", "Triangle"],
        medium: ["Circle", "Square", "Triangle", "Rectangle", "Pentagon"],
        hard: ["Circle", "Square", "Triangle", "Rectangle", "Pentagon", "Hexagon", "Oval", "Star"],
        matches: {
            "Circle": "Wheel",
            "Square": "Box",
            "Triangle": "Pyramid",
            "Rectangle": "Door",
            "Pentagon": "Home Plate",
            "Hexagon": "Honeycomb",
            "Oval": "Egg",
            "Star": "Starfish"
        }
    },
    "Countries and Capitals": {
        easy: ["India", "France", "Japan"],
        medium: ["India", "France", "Japan", "USA", "Germany"],
        hard: ["India", "France", "Japan", "USA", "Germany", "Russia", "Australia", "Brazil"],
        matches: {
            "India": "New Delhi",
            "France": "Paris",
            "Japan": "Tokyo",
            "USA": "Washington, D.C.",
            "Germany": "Berlin",
            "Russia": "Moscow",
            "Australia": "Canberra",
            "Brazil": "Brasília"
        }
    }
};

let selectedCategory = '';
let level = 'easy';
let score = 0;
let matches = 0;
let attempts = 0; 
let correctMatches = 0;
let incorrectMatches = 0;

function shuffleArray(array) {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
    }
    return array;
}

function speak(text) {
    const msg = new SpeechSynthesisUtterance();
    msg.text = text;
    window.speechSynthesis.speak(msg);
}

function setCategory(category) {
    selectedCategory = category;
    speak(`You have selected the category: ${category}. Please select a level.`);
    document.getElementById('category-selection').style.display = 'none';
    document.getElementById('level-selection').style.display = 'block';
}

function setLevel(selectedLevel) {
    level = selectedLevel;
    speak(`You have selected the ${selectedLevel} level. Good luck!`);
    document.getElementById('game-area').style.display = 'flex';
    document.getElementById('level-selection').style.display = 'none';
    generateItems(level);
}

function generateItems(level) {
    const items = categories[selectedCategory][level];
    const matchesList = shuffleArray([...Object.values(categories[selectedCategory].matches)]);

    const itemsUl = document.getElementById('items');
    const matchesUl = document.getElementById('matches');

    itemsUl.innerHTML = '';
    matchesUl.innerHTML = '';

    items.forEach((item, index) => {
        const li = document.createElement('li');
        li.draggable = true;
        li.id = 'item-' + index;
        li.innerHTML = item;
        li.ondragstart = (event) => drag(event);
        itemsUl.appendChild(li);
    });

    matchesList.forEach((match, index) => {
        const li = document.createElement('li');
        li.id = 'match-' + index;
        li.ondrop = (event) => drop(event);
        li.ondragover = (event) => allowDrop(event);
        li.innerHTML = match;
        matchesUl.appendChild(li);
    });
}

function allowDrop(event) {
    event.preventDefault();
}

function drag(event) {
    event.dataTransfer.setData("text", event.target.id);
}

function drop(event) {
    event.preventDefault();
    const itemId = event.dataTransfer.getData("text");
    const itemElement = document.getElementById(itemId);
    const itemText = itemElement.innerHTML;
    const matchText = event.target.innerHTML;

    attempts++;

    if (isMatch(itemText, matchText)) {
        itemElement.style.backgroundColor = "#32CD32"; // Correct match color
        event.target.style.backgroundColor = "#32CD32";
        itemElement.draggable = false;
        event.target.ondrop = null;
        matches++;
        correctMatches++;
        score += 10;
        speak(`Correct match! ${itemText} goes with ${matchText}.`);
    } else {
        itemElement.style.backgroundColor = "#FF6347"; // Incorrect match color
        event.target.style.backgroundColor = "#FF6347";
        incorrectMatches++;
        score -= 5;
        speak(`Incorrect match. ${itemText} does not go with ${matchText}. Try again!`);
    }

    if (matches === categories[selectedCategory][level].length) {
        showScore();
    }
}

function isMatch(item, match) {
    return categories[selectedCategory].matches[item] === match;
}

function showScore() {
    const resultMessage = `All matches complete! Your score is ${score}. You had ${correctMatches} correct matches and ${incorrectMatches} incorrect matches.`;
    document.getElementById('result').innerHTML = resultMessage;
    document.getElementById('score').innerHTML = score;
    document.getElementById('attempts').innerHTML = attempts;
    document.getElementById('score-area').style.display = 'block';
    speak(resultMessage);
    visualizeScore();
}

function visualizeScore() {
    const ctx = document.getElementById('scoreChart').getContext('2d');
    new Chart(ctx, {
        type: 'pie',
        data: {
            labels: ['Correct Matches', 'Incorrect Matches'],
            datasets: [{
                data: [correctMatches, incorrectMatches],
                backgroundColor: ['#32CD32', '#FF6347'],
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'top',
                },
                title: {
                    display: true,
                    text: 'Match Results'
                }
            }
        }
    });
}

function playAgain() {
    score = 0;
    matches = 0;
    attempts = 0;
    correctMatches = 0;
    incorrectMatches = 0;
    document.getElementById('game-area').style.display = 'none';
    document.getElementById('score-area').style.display = 'none';
    document.getElementById('category-selection').style.display = 'block';
    document.getElementById('result').innerHTML = '';
    speak("Let's play again! Please select a category.");
}
