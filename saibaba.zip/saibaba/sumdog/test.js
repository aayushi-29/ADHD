let isMuted = false; // Mute state
let currentQuestion = 0; // Index of the current question
let score = 0; // Track the total score
let correctAnswers = { addition: 0, subtraction: 0, multiplication: 0, division: 0 }; // Track correct answers by operation type

// Question set (4 questions for each type)
const questionSet = [
    // Addition questions
    { question: '2 + 3', correctAnswer: '5', options: ['4', '5', '6', '7'], type: 'addition' },
    { question: '7 + 5', correctAnswer: '12', options: ['11', '12', '10', '9'], type: 'addition' },
    { question: '6 + 8', correctAnswer: '14', options: ['12', '13', '14', '15'], type: 'addition' },
    { question: '10 + 9', correctAnswer: '19', options: ['18', '19', '20', '21'], type: 'addition' },
    // Subtraction questions
    { question: '9 - 4', correctAnswer: '5', options: ['6', '5', '4', '3'], type: 'subtraction' },
    { question: '15 - 7', correctAnswer: '8', options: ['8', '7', '6', '5'], type: 'subtraction' },
    { question: '20 - 6', correctAnswer: '14', options: ['14', '13', '12', '11'], type: 'subtraction' },
    { question: '12 - 9', correctAnswer: '3', options: ['2', '3', '4', '5'], type: 'subtraction' },
    // Multiplication questions
    { question: '3 * 4', correctAnswer: '12', options: ['11', '12', '13', '14'], type: 'multiplication' },
    { question: '5 * 6', correctAnswer: '30', options: ['28', '29', '30', '31'], type: 'multiplication' },
    { question: '7 * 8', correctAnswer: '56', options: ['55', '56', '57', '58'], type: 'multiplication' },
    { question: '6 * 9', correctAnswer: '54', options: ['53', '54', '55', '56'], type: 'multiplication' },
    // Division questions
    { question: '20 ÷ 4', correctAnswer: '5', options: ['4', '5', '6', '7'], type: 'division' },
    { question: '18 ÷ 3', correctAnswer: '6', options: ['5', '6', '7', '8'], type: 'division' },
    { question: '16 ÷ 2', correctAnswer: '8', options: ['7', '8', '9', '10'], type: 'division' },
    { question: '24 ÷ 6', correctAnswer: '4', options: ['3', '4', '5', '6'], type: 'division' }
];

// Initialize first question
function startTest() {
    showQuestion();
}

// Show the current question and answer options
function showQuestion() {
    if (currentQuestion < questionSet.length) {
        const current = questionSet[currentQuestion];
        document.getElementById('question-area').innerText = `${current.question} = ?`;

        // Reset button colors
        document.querySelectorAll('.answer-btn').forEach(btn => {
            btn.style.backgroundColor = ''; // Reset background color
            btn.disabled = false; // Enable buttons again
        });

        // Assign options to buttons
        document.getElementById('option1').innerText = current.options[0];
        document.getElementById('option2').innerText = current.options[1];
        document.getElementById('option3').innerText = current.options[2];
        document.getElementById('option4').innerText = current.options[3];

        // Speak the question using speech synthesis
        const speech = new SpeechSynthesisUtterance();
        speech.text = `What is ${current.question}?`;
        if (!isMuted) {
            window.speechSynthesis.speak(speech);
        }
    } else {
        endTest(); // End test after the last question
    }
}

// Handle answer button clicks
document.querySelectorAll('.answer-btn').forEach((btn, index) => {
    btn.addEventListener('click', function() {
        checkAnswer(index);
    });
});

// Check if the selected answer is correct
function checkAnswer(selectedOption) {
    const current = questionSet[currentQuestion];
    const selectedAnswer = current.options[selectedOption];

    // Disable all buttons after selecting an answer
    document.querySelectorAll('.answer-btn').forEach(btn => btn.disabled = true);

    if (selectedAnswer === current.correctAnswer) {
        document.getElementById(`option${selectedOption + 1}`).style.backgroundColor = 'green'; // Turn correct button green
        score++;
        correctAnswers[current.type]++; // Increment correct answers by operation type
    } else {
        document.getElementById(`option${selectedOption + 1}`).style.backgroundColor = 'red'; // Turn wrong button red

        // Highlight the correct answer
        const correctIndex = current.options.indexOf(current.correctAnswer);
        document.getElementById(`option${correctIndex + 1}`).style.backgroundColor = 'green';
    }

    currentQuestion++;
    document.getElementById('next-question-btn').style.display = 'block'; // Show "Next Question" button
}

// Handle the next question button click
document.getElementById('next-question-btn').addEventListener('click', function() {
    document.getElementById('next-question-btn').style.display = 'none'; // Hide the button after click
    showQuestion(); // Show the next question
});

// Mute/unmute the voice assistant
document.getElementById('mute-btn').addEventListener('click', function() {
    isMuted = !isMuted;
    this.textContent = isMuted ? 'Unmute Voice' : 'Mute Voice';
});

// End test and display results
function endTest() {
    // Redirect to analysis page and pass the score data
    window.location.href = `analysis.html?addition=${correctAnswers.addition}&subtraction=${correctAnswers.subtraction}&multiplication=${correctAnswers.multiplication}&division=${correctAnswers.division}`;
}

startTest(); // Start the test on page load
