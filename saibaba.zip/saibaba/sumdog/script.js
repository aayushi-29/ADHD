let isMuted = false; // Mute state variable
let currentExample = 0; // Index for current tutorial example

// Content for the tutorial examples
const tutorialContent = [
    // Addition examples
    { expression: '2 + 3 = 5', explanation: '2 plus 3 equals 5.' },
    { expression: '7 + 4 = 11', explanation: '7 plus 4 equals 11.' },
    { expression: '10 + 5 = 15', explanation: '10 plus 5 equals 15.' },
    { expression: '6 + 8 = 14', explanation: '6 plus 8 equals 14.' },
    // Subtraction examples
    { expression: '5 - 3 = 2', explanation: '5 minus 3 equals 2.' },
    { expression: '9 - 4 = 5', explanation: '9 minus 4 equals 5.' },
    { expression: '12 - 6 = 6', explanation: '12 minus 6 equals 6.' },
    { expression: '15 - 7 = 8', explanation: '15 minus 7 equals 8.' },
    // Multiplication examples
    { expression: '3 * 4 = 12', explanation: '3 times 4 equals 12.' },
    { expression: '5 * 2 = 10', explanation: '5 times 2 equals 10.' },
    { expression: '6 * 3 = 18', explanation: '6 times 3 equals 18.' },
    { expression: '8 * 7 = 56', explanation: '8 times 7 equals 56.' },
    // Division examples
    { expression: '10 ÷ 2 = 5', explanation: '10 divided by 2 equals 5.' },
    { expression: '20 ÷ 4 = 5', explanation: '20 divided by 4 equals 5.' },
    { expression: '18 ÷ 3 = 6', explanation: '18 divided by 3 equals 6.' },
    { expression: '16 ÷ 4 = 4', explanation: '16 divided by 4 equals 4.' }
];

// Start the tutorial
document.getElementById('speak-btn').addEventListener('click', function() {
    startTutorial(); // Start the tutorial
});

function startTutorial() {
    document.getElementById('operation-explanation').innerText = ''; // Clear previous explanations
    showNextExample(); // Show the first example
}

function showNextExample() {
    if (currentExample < tutorialContent.length) {
        const current = tutorialContent[currentExample];
        const expression = current.expression;
        const operationText = current.explanation;

        // Display the mathematical expression
        document.getElementById('floating-numbers').innerText = expression;

        // Display operation explanation
        document.getElementById('operation-explanation').innerText = operationText;

        // Initialize speech synthesis for the explanation
        const speech = new SpeechSynthesisUtterance();
        speech.text = operationText;
        if (!isMuted) {
            window.speechSynthesis.speak(speech);
        }

        // Show the "Next Example" button and manage its visibility
        document.getElementById('next-btn').style.display = 'block';
        if (currentExample === tutorialContent.length - 1) {
            document.getElementById('next-btn').style.display = 'none'; // Hide when last example is reached
            document.getElementById('start-test-btn').style.display = 'block'; // Show start test button
        }

        currentExample++;
    }
}

// Mute/unmute the voice assistant
document.getElementById('mute-btn').addEventListener('click', function() {
    isMuted = !isMuted; // Toggle mute state
    this.textContent = isMuted ? 'Unmute Voice' : 'Mute Voice'; // Update button text
});

// Next example button
document.getElementById('next-btn').addEventListener('click', function() {
    showNextExample(); // Show the next tutorial example
});

// Start test button
document.getElementById('start-test-btn').addEventListener('click', function() {
    window.location.href = 'test.html'; // Redirect to the test page
});
