const testArea = document.getElementById('testArea');
const testQuestion = document.getElementById('testQuestion');
const testOptions = document.getElementById('testOptions');
const totalDisplay = document.getElementById('total');
const restartBtn = document.getElementById('restartBtn');
const questionImage = document.getElementById('questionImage'); // New element for the image

let score = 0;
let currentQuestionIndex = 0;

// Updated questions with color names, their respective colors, and local image paths
const testQuestions = [
    {
        question: "What color is the sky?",
        options: ["Red", "Blue", "Green", "Yellow"],
        correct: "Blue",
        image: "sky.jpeg" // Local image path
    },
    {
        question: "What color is grass?",
        options: ["Purple", "Orange", "Green", "Pink"],
        correct: "Green",
        image: "grass.jpeg" // Local image path
    },
    {
        question: "What color is a banana?",
        options: ["Brown", "Green", "Yellow", "Blue"],
        correct: "Yellow",
        image: "banana.jpeg" // Local image path
    },
    {
        question: "What color are strawberries?",
        options: ["Blue", "Red", "Green", "White"],
        correct: "Red",
        image: "strawberries.jpeg" // Local image path
    },
    {
        question: "What color is an orange?",
        options: ["Purple", "Orange", "Yellow", "Brown"],
        correct: "Orange",
        image: "orange.jpeg" // Local image path
    },
    {
        question: "What color is a lemon?",
        options: ["Pink", "Green", "Yellow", "Blue"],
        correct: "Yellow",
        image: "lemon.jpeg" // Local image path
    },
    {
        question: "What color are blueberries?",
        options: ["Red", "Yellow", "Blue", "Purple"],
        correct: "Blue",
        image: "blueberries.jpeg" // Local image path
    },
    {
        question: "What color is the sun?",
        options: ["White", "Blue", "Yellow", "Gray"],
        correct: "Yellow",
        image: "sun.jpeg" // Local image path
    },
    {
        question: "What color is a fire truck?",
        options: ["Blue", "Red", "Green", "Yellow"],
        correct: "Red",
        image: "fire truck.jpeg" // Local image path
    },
    {
        question: "What color are cucumbers?",
        options: ["Orange", "Purple", "Green", "Black"],
        correct: "Green",
        image: "cucumbers.jpeg" // Local image path
    }
];

// Start the test
function startTest() {
    score = 0; // Reset score
    currentQuestionIndex = 0; // Reset question index
    testArea.style.display = 'block'; // Show test area
    showQuestion(); // Display the first question
}

// Show the current question
function showQuestion() {
    const currentQuestion = testQuestions[currentQuestionIndex];
    testQuestion.textContent = currentQuestion.question;
    questionImage.src = currentQuestion.image; // Set the image for the question
    testOptions.innerHTML = ''; // Clear previous options

    currentQuestion.options.forEach(option => {
        const button = document.createElement('button');
        button.textContent = option;
        button.className = 'optionBtn';
        button.style.backgroundColor = option.toLowerCase(); // Set background color based on the option
        button.addEventListener('click', () => selectOption(option));
        testOptions.appendChild(button);
    });

    voiceAssistant(currentQuestion.question); // Ask the question using voice assistant
}

// Handle option selection
function selectOption(selected) {
    const currentQuestion = testQuestions[currentQuestionIndex];
    if (selected === currentQuestion.correct) {
        score++; // Increment score for correct answer
        voiceAssistant('Correct!'); // Provide voice feedback
    } else {
        voiceAssistant(`Incorrect. The correct answer was ${currentQuestion.correct}.`); // Voice feedback for incorrect answer
    }

    currentQuestionIndex++; // Move to the next question
    if (currentQuestionIndex < testQuestions.length) {
        showQuestion(); // Show next question
    } else {
        endTest(); // End the test if all questions are answered
    }
}

// End the test and show results
function endTest() {
    testArea.style.display = 'none'; // Hide test area
    totalDisplay.textContent = `Your score: ${score}/${testQuestions.length}`; // Show final score
    
    // Store the score in localStorage and redirect to the analysis page
    localStorage.setItem('testScore', score);
    window.location.href = 'analysis.html'; // Redirect to analysis page
}

// Restart the test
restartBtn.addEventListener('click', () => {
    score = 0;
    currentQuestionIndex = 0;
    totalDisplay.textContent = '';
    startTest(); // Start the test again
});

// Voice Assistant Function
function voiceAssistant(text) {
    const utterance = new SpeechSynthesisUtterance(text);
    speechSynthesis.speak(utterance);
}

// Initialize the test when the page loads
window.onload = () => {
    startTest();
};
