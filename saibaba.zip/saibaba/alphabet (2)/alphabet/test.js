// Test questions
const testQuestions = [
    { question: "What comes after A?", options: ["B", "C", "D"], correct: "B" },
    { question: "What comes after B?", options: ["A", "C", "D"], correct: "C" },
    { question: "What comes after C?", options: ["D", "B", "E"], correct: "D" },
    { question: "What comes after D?", options: ["E", "C", "F"], correct: "E" },
    { question: "What comes after E?", options: ["F", "D", "G"], correct: "F" },
    { question: "What comes after F?", options: ["G", "E", "H"], correct: "G" },
    { question: "What comes after G?", options: ["H", "F", "I"], correct: "H" },
    { question: "What comes after H?", options: ["I", "G", "J"], correct: "I" },
    { question: "What comes after I?", options: ["H", "J", "K"], correct: "J" },
    { question: "What comes after J?", options: ["K", "I", "L"], correct: "K" },
    // You can continue adding more questions if needed
];

let score = 0;
let currentQuestionIndex = 0;

// Speech synthesis
const synth = window.speechSynthesis;

// Display test question
function showQuestion() {
    const currentQuestion = testQuestions[currentQuestionIndex];
    document.getElementById('testQuestion').textContent = currentQuestion.question;
    speak(currentQuestion.question); // Read the question aloud

    const testOptions = document.getElementById('testOptions');
    testOptions.innerHTML = '';
    currentQuestion.options.forEach(option => {
        const optionBtn = document.createElement('button');
        optionBtn.textContent = option;
        optionBtn.addEventListener('click', () => selectOption(option));
        testOptions.appendChild(optionBtn);
    });
}

// Speak text using voice assistant
function speak(text) {
    const utterance = new SpeechSynthesisUtterance(text);
    synth.speak(utterance);
}

// Handle option selection
function selectOption(selectedOption) {
    const currentQuestion = testQuestions[currentQuestionIndex];
    if (selectedOption === currentQuestion.correct) {
        score++;
        speak("Correct!");
    } else {
        speak("Incorrect. The correct answer is " + currentQuestion.correct);
    }
    currentQuestionIndex++;
    if (currentQuestionIndex < testQuestions.length) {
        showQuestion();
    } else {
        endTest();
    }
}

// Display final score
function endTest() {
    localStorage.setItem('score', score);
    localStorage.setItem('totalQuestions', testQuestions.length);
    window.location.href = 'analysis.html';
}

document.getElementById('finishTestBtn').addEventListener('click', endTest);
showQuestion();
