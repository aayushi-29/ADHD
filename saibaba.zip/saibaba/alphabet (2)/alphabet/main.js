// Select elements
const alphabetArea = document.getElementById('alphabetArea');
const startTestBtn = document.getElementById('startTestBtn');
const resetBtn = document.getElementById('resetBtn');

// Alphabet letters with sample words
const alphabetData = [
    { letter: "A", word: "Apple" },
    { letter: "B", word: "Ball" },
    { letter: "C", word: "Cat" },
    { letter: "D", word: "Dog" },
    { letter: "E", word: "Elephant" },
    { letter: "F", word: "Fish" },
    { letter: "G", word: "Grape" },
    { letter: "H", word: "Hat" },
    { letter: "I", word: "Ice" },
    { letter: "J", word: "Jug" },
    { letter: "K", word: "Kite" },
    { letter: "L", word: "Lion" },
    { letter: "M", word: "Monkey" },
    { letter: "N", word: "Nest" },
    { letter: "O", word: "Orange" },
    { letter: "P", word: "Panda" },
    { letter: "Q", word: "Queen" },
    { letter: "R", word: "Rabbit" },
    { letter: "S", word: "Sun" },
    { letter: "T", word: "Tree" },
    { letter: "U", word: "Umbrella" },
    { letter: "V", word: "Violin" },
    { letter: "W", word: "Whale" },
    { letter: "X", word: "Xylophone" },
    { letter: "Y", word: "Yacht" },
    { letter: "Z", word: "Zebra" },
];

let currentAlphabetIndex = 0;

// Speech synthesis
const synth = window.speechSynthesis;

// Display alphabet learning area
function displayAlphabet() {
    // Clear previous content
    alphabetArea.innerHTML = '';

    // Show four letters at a time
    for (let i = 0; i < 4; i++) {
        const index = currentAlphabetIndex + i;
        if (index < alphabetData.length) {
            const data = alphabetData[index];
            const letterBox = document.createElement('div');
            letterBox.className = 'letterBox';
            letterBox.textContent = `${data.letter} - ${data.word}`;
            letterBox.style.fontSize = '24px';
            letterBox.style.color = '#4A90E2';
            alphabetArea.appendChild(letterBox);

            // Speak the letter and its corresponding word
            speak(`${data.letter} - ${data.word}`);
        }
    }
}

// Speak text using voice assistant
function speak(text) {
    const utterance = new SpeechSynthesisUtterance(text);
    synth.speak(utterance);
}

// Reset button event
resetBtn.addEventListener('click', () => {
    currentAlphabetIndex += 4;
    if (currentAlphabetIndex >= alphabetData.length) {
        currentAlphabetIndex = 0; // Reset to the beginning
    }
    displayAlphabet();
});

// Start Test Button Event
startTestBtn.addEventListener('click', () => {
    window.location.href = 'test.html';
});

// Initial display of the alphabet
displayAlphabet();
