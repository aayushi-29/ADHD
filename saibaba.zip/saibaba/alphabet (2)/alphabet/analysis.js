const score = parseInt(localStorage.getItem('score'));
const totalQuestions = parseInt(localStorage.getItem('totalQuestions'));
document.getElementById('scoreDisplay').textContent = `Score: ${score}/${totalQuestions}`;

const ctx = document.getElementById('pieChart').getContext('2d');
const highKnowledge = (score / totalQuestions) >= 0.8 ? score : 0;
const mediumKnowledge = (score / totalQuestions) >= 0.5 && (score / totalQuestions) < 0.8 ? score : 0;
const lowKnowledge = (score / totalQuestions) < 0.5 ? score : 0;

new Chart(ctx, {
    type: 'pie',
    data: {
        labels: ['High Knowledge', 'Medium Knowledge', 'Low Knowledge'],
        datasets: [{
            data: [highKnowledge, mediumKnowledge, lowKnowledge],
            backgroundColor: ['green', 'orange', 'red'],
        }]
    },
});

document.getElementById('restartTestBtn').addEventListener('click', () => {
    window.location.href = 'index.html';
});
