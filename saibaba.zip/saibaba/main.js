const dropArea = document.getElementById('dropArea');
const startTestBtn = document.getElementById('startTestBtn');
const scoreDisplay = document.getElementById('scoreDisplay');
const colorContainer = document.getElementById('colorContainer'); // New element for colors

let score = 0; // Variable to keep track of score

// Start the game and add drag-and-drop colors
function startGame() {
    dropArea.innerHTML = ''; // Clear drop area
    colorContainer.innerHTML = ''; // Clear previous color boxes

    const colors = ['red', 'blue', 'green', 'yellow', 'orange', 'purple', 'pink', 'cyan', 'magenta'];
    
    colors.forEach(color => {
        const colorBox = document.createElement('div');
        colorBox.className = 'colorBox'; // Add class for styling
        colorBox.style.backgroundColor = color;
        colorBox.draggable = true;
        colorBox.addEventListener('dragstart', (event) => {
            event.dataTransfer.setData('text/plain', color);
        });

        // Create a color name element
        const colorName = document.createElement('div');
        colorName.className = 'colorName';
        colorName.textContent = color; // Set the color name

        // Append the name to the color box
        colorBox.appendChild(colorName);
        colorContainer.appendChild(colorBox); // Add the color box to the container
    });

    dropArea.addEventListener('dragover', (event) => {
        event.preventDefault(); // Prevent default to allow drop
    });

    dropArea.addEventListener('drop', (event) => {
        event.preventDefault();
        const draggedColor = event.dataTransfer.getData('text/plain');
        dropArea.style.backgroundColor = draggedColor; // Change drop area color
        voiceAssistant(`You dropped ${draggedColor}`); // Voice feedback
        score++; // Increment score
        scoreDisplay.textContent = `Score: ${score}`;
    });
}

// Voice Assistant Function
function voiceAssistant(text) {
    const utterance = new SpeechSynthesisUtterance(text);
    speechSynthesis.speak(utterance);
}

// Start the test
startTestBtn.addEventListener('click', () => {
    window.location.href = 'test.html'; // Redirect to test page
});

// Initialize the game when the page loads
window.onload = () => {
    startGame();
};
